#: THIS IS NOT JSON FILE IT'S PYTHON DICTIONARY

styles={
    "_3991": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "height": "",
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 1"",
        "width": "450"
    },
    "_3992": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 39.0,
        "text_align": "left",
        # "tooltip": ""Text"",
        "value": "Servicios Gastronomicos. Formatur Varadero",
        "weight": "bold"
    },
    "_3999": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":-1,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "height": "65",
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Column: 3"",
        "width": ""
    },
    "_4000": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS",
        "wrap": "true"
    },
    "_4015": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 7""
    },
    "_4016": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "height": "",
        "size": 15.0,
        "text_align": "left",
        # "tooltip": ""Text"",
        "value": "Profesor: Lic Ramon",
        "weight": "normal",
        "width": "240"
    },
    "_4003": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":1,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "height": "150",
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 4"",
        "width": "640"
    },
    "_4004": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 13.0,
        "text_align": "start",
        # "tooltip": ""Text"",
        "value": "¡Estás invitado! Únase a nosotros para una sesión informativa sobre las mejores prácticas para los camareros. Aprenda habilidades esenciales, consejos para un servicio excepcional y cómo mejorar la experiencia gastronómica. ¡No se pierda esta oportunidad de elevar su carrera!"
    },
    "_4007": {
        # "WIDGET_NAME": "CONTAINER_ROW",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "ink": "true",
        "ink_color": "cyan",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Row: 5""
    },
    "_4008": {
        # "WIDGET_NAME": "CONTENT_ROW",
        "scroll": "ALWAYS"
    },
    "_4027": {
        # "WIDGET_NAME": "CONTAINER_ROW",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":47.0,"br":47.0,"tl":47.0,"tr":47.0},
        "height": "",
        "ink": "true",
        "ink_color": "cyan",
        "margin": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        "padding": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        # "tooltip": ""Row: 10"",
        "width": "280"
    },
    "_4028": {
        # "WIDGET_NAME": "CONTENT_ROW",
        "scroll": "ALWAYS"
    },
    "_4031": {
        # "WIDGET_NAME": "CONTAINER_ICON",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":47.0,"br":47.0,"tl":47.0,"tr":47.0},
        "height": "",
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Icon: 11"",
        "width": ""
    },
    "_4032": {
        # "WIDGET_NAME": "CONTENT_ICON",
        "name": "home",
        # "tooltip": ""Icon"",
    },
    "_4035": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":47.0,"br":47.0,"tl":47.0,"tr":47.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 12""
    },
    "_4036": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 32.0,
        # "tooltip": ""Text"",
        "value": "Comencemos",
        "weight": "bold"
    },
    "_4043": {
        # "WIDGET_NAME": "CONTAINER_ROW",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "height": "50",
        "ink": "true",
        "ink_color": "cyan",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Row: 14"",
        "width": ""
    },
    "_4044": {
        # "WIDGET_NAME": "CONTENT_ROW",
        "scroll": "ALWAYS"
    }
}