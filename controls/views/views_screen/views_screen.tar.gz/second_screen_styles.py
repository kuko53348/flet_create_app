#: THIS IS NOT JSON FILE IT'S PYTHON DICTIONARY

styles={
    "_4131": {
        # "WIDGET_NAME": "CONTAINER_STACK",
        "alignment": {"x":-1,"y":-1},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "expand": "1",
        "height": "",
        "ink": "true",
        "ink_color": "purple",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Stack: 37"",
        "width": "645"
    },
    "_4132": {
        # "WIDGET_NAME": "CONTENT_STACK",
        "visible": "true"
    },
    "_4139": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":-1},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Column: 39""
    },
    "_4140": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "height": "",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS",
        "width": "640"
    },
    "_4143": {
        # "WIDGET_NAME": "CONTAINER_ROW",
        "alignment": {"x":-1,"y":0},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "cyan",
        "margin": {"l":8.0,"t":8.0,"r":8.0,"b":8.0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"black54","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Row: 40""
    },
    "_4144": {
        # "WIDGET_NAME": "CONTENT_ROW",
        "height": "",
        "scroll": "ALWAYS",
        "width": ""
    },
    "_4147": {
        # "WIDGET_NAME": "CONTAINER_ICONBUTTON",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Icon Button: 41""
    },
    "_4148": {
        # "WIDGET_NAME": "CONTENT_ICONBUTTON",
        "icon": "add_link_sharp",
        # "tooltip": ""Accept""
    },
    "_4151": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":-1,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":12,"br":12,"tl":12,"tr":12},
        "height": "",
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 42"",
        "width": "310"
    },
    "_4152": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "height": "",
        "size": 14.0,
        # "tooltip": ""Text"",
        "value": "3.1 Tarea diaria. Definiciu00f3n. Etapas: Apertura y cierre. Tareas a realizar. ",
        "width": "310 "
    },
    "_4155": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":-1},
        "bgcolor": "black54",
        "blur": ["20","20"],
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "height": "",
        "image_fit": "cover",
        "image_opacity": "0.020000000000000018",
        "image_src": "test/proyect_name/proyect_name/assets/3b828654-cf7d-459b-8c94-a2797c98084c.webp",
        "ink": "true",
        "ink_color": "yellow",
        "margin": {"l":6.0,"t":6.0,"r":6.0,"b":6.0},
        "padding": {"l":16.0,"t":16.0,"r":16.0,"b":16.0},
        # "tooltip": ""Column: 43"",
        "visible": "true",
        # "visible": "false",
        "width": "645"
    },
    "_4156": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "height": "",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS",
        "width": "640"
    },
    "_4159": {
        # "WIDGET_NAME": "CONTAINER_ROW",
        "alignment": {"x":-1,"y":0},
        "bgcolor": "white10",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "cyan",
        "padding": {"l":4.0,"t":4.0,"r":4.0,"b":4.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"black87","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Row: 44""
    },
    "_4160": {
        # "WIDGET_NAME": "CONTENT_ROW",
        "scroll": "ALWAYS"
    },
    "_4163": {
        # "WIDGET_NAME": "CONTAINER_ICON",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Icon: 45""
    },
    "_4164": {
        # "WIDGET_NAME": "CONTENT_ICON",
        "name": "add_reaction_outlined",
        # "tooltip": ""Icon""
    },
    "_4167": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":12,"br":12,"tl":12,"tr":12},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 46""
    },
    "_4168": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 17.0,
        # "tooltip": ""Text"",
        "value": "Ready to make your first app!!"
    },
    "_4135": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "height": "120",
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Column: 38"",
        "width": ""
    },
    "_4136": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    }
}