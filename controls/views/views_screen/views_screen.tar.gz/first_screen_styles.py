#: THIS IS NOT JSON FILE IT'S PYTHON DICTIONARY

styles={
    "_3987": {
        # "WIDGET_NAME": "CONTAINER_GRIDVIEW",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "height": "",
        "ink": "true",
        "ink_color": "green",
        "margin": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        # "tooltip": ""GridView: 1"",
        "width": "640"
    },
    "_3988": {
        # "WIDGET_NAME": "CONTENT_GRIDVIEW",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "runs_count": "2",
        "run_spacing": "9.0",
        "spacing": 9.0
    },
    "_3991": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "image_opacity": "1.0",
        "image_src": "test/proyect_name/proyect_name/assets/_88292cbc-1dd1-42da-b9fa-6aa695c85199.jpeg",
        "ink": "true",
        "ink_color": "yellow",
        "margin": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        "padding": {"l":12.0,"t":12.0,"r":12.0,"b":12.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"scrim","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Column: 2""
    },
    "_3992": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_4067": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 21""
    },
    "_4068": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 21.0,
        # "tooltip": ""Text"",
        "value": "Capitulo 1",
        "weight": "bold"
    },
    "_4071": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 22""
    },
    "_4072": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 10.0,
        "text_align": "right",
        # "tooltip": ""Text"",
        "value": "Indtroduccion a la Gastronomia",
        "weight": "normal"
    },
    "_3995": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "image_opacity": "1.0",
        "image_src": "test/proyect_name/proyect_name/assets/3b828654-cf7d-459b-8c94-a2797c98084c.webp",
        "ink": "true",
        "ink_color": "yellow",
        "margin": {"l":{"l":2.0,"t":2.0,"r":2.0,"b":2.0},"t":{"l":2.0,"t":2.0,"r":2.0,"b":2.0},"r":{"l":2.0,"t":2.0,"r":2.0,"b":2.0},"b":{"l":2.0,"t":2.0,"r":2.0,"b":2.0}},
        "padding": {"l":12.0,"t":12.0,"r":12.0,"b":12.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"scrim","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Column: 3""
    },
    "_3996": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_4035": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"black87","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Text: 13""
    },
    "_4036": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 21.0,
        # "tooltip": ""Text"",
        "value": "Capitulo 2",
        "weight": "bold"
    },
    "_4075": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 23""
    },
    "_4076": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 10.0,
        "text_align": "right",
        # "tooltip": ""Text"",
        "value": "Utensilios de trabajo y servicios"
    },
    "_3999": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "image_opacity": "1.0",
        "image_src": "test/proyect_name/proyect_name/assets/_97376971-d574-4e82-9f1c-deb13a37c47a.jpeg",
        "ink": "true",
        "ink_color": "yellow",
        "margin": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        "padding": {"l":12.0,"t":12.0,"r":12.0,"b":12.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"scrim","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Column: 4""
    },
    "_4000": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_4039": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 14""
    },
    "_4040": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 21.0,
        # "tooltip": ""Text"",
        "value": "Capitulo 3",
        "weight": "bold"
    },
    "_4079": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 24""
    },
    "_4080": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 10.0,
        "text_align": "right",
        # "tooltip": ""Text"",
        "value": "Funsiones y etapa Tarea diaria"
    },
    "_4003": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "image_opacity": "1.0",
        "image_src": "test/proyect_name/proyect_name/assets/_7b6c3bb9-28cf-4fd3-b9ef-2613bd95903d.jpeg",
        "ink": "true",
        "ink_color": "yellow",
        "margin": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        "padding": {"l":12.0,"t":12.0,"r":12.0,"b":12.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"scrim","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Column: 5""
    },
    "_4004": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_4043": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 15""
    },
    "_4044": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 21.0,
        # "tooltip": ""Text"",
        "value": "Capitulo 4",
        "weight": "bold"
    },
    "_4083": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 25""
    },
    "_4084": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "bgcolor": "transparent",
        "size": 10.0,
        "text_align": "right",
        # "tooltip": ""Text"",
        "value": "Normas basicas y preferencias"
    },
    "_4007": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "image_src": "test/proyect_name/proyect_name/assets/_e5f9c730-4a90-466c-9738-e7c83cdb45f5.jpeg",
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":12.0,"t":12.0,"r":12.0,"b":12.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"scrim","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Column: 6""
    },
    "_4008": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_4047": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 16""
    },
    "_4048": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 21.0,
        # "tooltip": ""Text"",
        "value": "Capitulo 5",
        "weight": "bold"
    },
    "_4087": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 26""
    },
    "_4088": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 10.0,
        "text_align": "right",
        # "tooltip": ""Text"",
        "value": "Tipos de servicios e instalaciones"
    },
    "_4011": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "image_src": "test/proyect_name/proyect_name/assets/_d36bbf7a-c98f-4306-a8ac-8b9ea86d4e97.jpeg",
        "ink": "false",
        "ink_color": "yellow",
        "padding": {"l":12.0,"t":12.0,"r":12.0,"b":12.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"scrim","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Column: 7""
    },
    "_4012": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_4051": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 17""
    },
    "_4052": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 21.0,
        # "tooltip": ""Text"",
        "value": "Capitulo 6",
        "weight": "bold"
    },
    "_4091": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 27""
    },
    "_4092": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 10.0,
        "text_align": "right",
        # "tooltip": ""Text"",
        "value": "Clasificacion de Vinos y Maridajes"
    },
    "_4015": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "image_src": "test/proyect_name/proyect_name/assets/_0fcbf8aa-7625-4a0d-85e3-9e62b7b8445c.jpeg",
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":12.0,"t":12.0,"r":12.0,"b":12.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"scrim","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Column: 8""
    },
    "_4016": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_4055": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 18""
    },
    "_4056": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 21.0,
        # "tooltip": ""Text"",
        "value": "Capitulo 7",
        "weight": "bold"
    },
    "_4095": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 28""
    },
    "_4096": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 10.0,
        "text_align": "right",
        # "tooltip": ""Text"",
        "value": "Aervicio de fuente de Soda"
    },
    "_4019": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "image_src": "test/proyect_name/proyect_name/assets/_fa393391-e20b-4b4b-a491-29dca72f3462.jpeg",
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":12.0,"t":12.0,"r":12.0,"b":12.0},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"scrim","offset":{"x":0,"y":0},"blur_style":"outer"},
        # "tooltip": ""Column: 9""
    },
    "_4020": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_4059": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 19""
    },
    "_4060": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 21.0,
        # "tooltip": ""Text"",
        "value": "Capitulo 8",
        "weight": "bold"
    },
    "_4099": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black87",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":43.0,"br":43.0,"tl":43.0,"tr":43.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 29""
    },
    "_4100": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": 10.0,
        "text_align": "right",
        # "tooltip": ""Text"",
        "value": "Documentacion Utilizada"
    },
    "_4023": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "height": "120",
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Column: 10"",
        "width": ""
    },
    "_4024": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    }
}