#: MAIN WIDGET SCREEN CLASS
import flet as ft

from .second_screen_styles import styles
from .second_screen_events import *

#: STYLE TO MAIN SCREEN WIDGET
phone_style_widget = {
    "MAIN_CONTAINER": {
        "alignment": {"x":0,"y":0},
        "height": "625",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":0,"t":0,"r":0,"b":0},
        "width": "460",
        "image_src": "test/proyect_name/proyect_name/assets/_88292cbc-1dd1-42da-b9fa-6aa695c85199.jpeg",
        "image_opacity": "0.21999999999999997",
        "image_fit": "cover"
    },
    "MAIN_EFFECTS_CONTAINER": {
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "blur": {"sigma_x":20,"sigma_y":20,"tile_mode":"mirror"},
        "padding": {"l":0,"t":0,"r":0,"b":0}
    },
    "COLUMN_CONTAINER": {
        "alignment": "center",
        "scroll": "",
        "spacing": "2",
        "tight": "false",
        "horizontal_alignment": "center"
    }
}

class second_screen(ft.Container):

    def __init__(self):
        super().__init__()
        dict_keys: dict = self.second_screen_style(code='MAIN_CONTAINER')
        self: list      = [self.__setattr__(_ , dict_keys.get(_)) for _ in dict_keys]

    def build(self):

        #: MAIN PHONE CONTAINER
        self.content_box = [ 

		ft.Container(  # Container_Stack
			**self.dict_style('_4131'),
			content= ft.Stack( # Stack
					**self.dict_style('_4132'),
					controls= [

						ft.Container(  # Container_Column
								**self.dict_style('_4139'),
								content= ft.Column( # Column
										**self.dict_style('_4140'),
										controls= [

												ft.Container(  # Container_Row
														**self.dict_style('_4143'),
														content= ft.Row( # Row
																**self.dict_style('_4144'),
																controls= [

																		ft.Container( # IconButton
																				**self.dict_style('_4147'),
																				# on_click= lambda _: event_4148(data='_4148'),
																				content= ft.IconButton(
																						**self.dict_style('_4148'),
																						on_click= lambda _: event_4148(data='_4148'),
																				),),

																		ft.Container( # Text
																				**self.dict_style('_4151'),
																				# on_click= lambda _: event_4152(data='_4152'),
																				content= ft.Text(
																						**self.dict_style('_4152'),
																						# on_click= lambda _: event_4152(data='_4152'),
																				),),

												],),), #// LAYER 2 END
								],),), #// LAYER 1 END
						ft.Container(  # Container_Column
								**self.dict_style('_4155'),
								content= ft.Column( # Column
										**self.dict_style('_4156'),
										controls= [

												ft.Container(  # Container_Row
														**self.dict_style('_4159'),
														content= ft.Row( # Row
																**self.dict_style('_4160'),
																controls= [

																		ft.Container( # Icon
																				**self.dict_style('_4163'),
																				on_click= lambda _: event_4164(data='_4164'),
																				content= ft.Icon(
																						**self.dict_style('_4164'),
																						# on_click= lambda _: event_4164(data='_4164'),
																				),),

																		ft.Container( # Text
																				**self.dict_style('_4167'),
																				# on_click= lambda _: event_4168(data='_4168'),
																				content= ft.Text(
																						**self.dict_style('_4168'),
																						# on_click= lambda _: event_4168(data='_4168'),
																				),),

												],),), #// LAYER 2 END
								],),), #// LAYER 1 END
		],),),  
		ft.Container(  # Container_Column
			**self.dict_style('_4135'),
			content= ft.Column( # Column
					**self.dict_style('_4136'),
					controls= [

				],
		),), #// CLOSE LAYER 0
        ]

        #: MAIN PHONE CONTAINER
        self.content = ft.Container(
                            **self.second_screen_style(code='MAIN_EFFECTS_CONTAINER'),
                            content = ft.Column(
                                        **self.second_screen_style(code='COLUMN_CONTAINER'),
                                        controls = self.content_box
                                        ),
                                )

    def second_screen_style(self,code: str=''):
        #: SET MAIN STYLE WIDGET
        return phone_style_widget.get(code)

    def dict_style(self,code: str=''):
        #: SET CONTENT STYLE WIDGET
        return styles.get(code)

