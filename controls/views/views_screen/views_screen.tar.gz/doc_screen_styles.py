#: THIS IS NOT JSON FILE IT'S PYTHON DICTIONARY

styles={
    "_3987": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black54",
        "blur": ["20","20"],
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "height": "",
        "ink": "true",
        "ink_color": "yellow",
        "margin": {"l":6.0,"t":6.0,"r":6.0,"b":6.0},
        "padding": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        # "tooltip": ""Column: 1"",
        "width": "640"
    },
    "_3988": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_3999": {
        # "WIDGET_NAME": "CONTAINER_ROW",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "expand": "1",
        "height": "",
        "image_src": "test/proyect_name/proyect_name/assets/.comments",
        "ink": "true",
        "ink_color": "cyan",
        "margin": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        "padding": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        # "tooltip": ""Row: 4"",
        "width": ""
    },
    "_4000": {
        # "WIDGET_NAME": "CONTENT_ROW",
        "adaptive": "true",
        "alignment": "spaceBetween",
        "expand": "1",
        "height": "",
        "scroll": "ALWAYS",
        "tight": "false",
        "width": "",
        "wrap": "false"
    },
    "_4003": {
        # "WIDGET_NAME": "CONTAINER_ICONBUTTON",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black45",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Icon Button: 5""
    },
    "_4004": {
        # "WIDGET_NAME": "CONTENT_ICONBUTTON",
        "icon": "add_link_sharp",
        # "tooltip": ""Accept""
    },
    "_4007": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "expand": "1",
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Text: 6""
    },
    "_4008": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "expand": "1",
        "size": 23.0,
        "text_align": "left",
        # "tooltip": ""Text"",
        "value": "Surgimiento",
        "weight": "bold"
    },
    "_4011": {
        # "WIDGET_NAME": "CONTAINER_ROW",
        "alignment": {"x":0,"y":0},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "ink": "true",
        "ink_color": "cyan",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Row: 7""
    },
    "_4012": {
        # "WIDGET_NAME": "CONTENT_ROW",
        "scroll": "ALWAYS"
    },
    "_4015": {
        # "WIDGET_NAME": "CONTAINER_ICONBUTTON",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Icon Button: 8""
    },
    "_4016": {
        # "WIDGET_NAME": "CONTENT_ICONBUTTON",
        "icon": "home",
        # "tooltip": ""Accept""
    },
    "_4019": {
        # "WIDGET_NAME": "CONTAINER_ICONBUTTON",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Icon Button: 9""
    },
    "_4020": {
        # "WIDGET_NAME": "CONTENT_ICONBUTTON",
        "icon": "add",
        # "tooltip": ""Accept""
    },
    "_3991": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "blur": ["20","20"],
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "expand": "1",
        "height": "",
        "ink": "true",
        "ink_color": "yellow",
        "margin": {"l":8.0,"t":8.0,"r":8.0,"b":8.0},
        "padding": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        # "tooltip": ""Column: 2"",
        "width": "640"
    },
    "_3992": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "adaptive": "true",
        "expand": "1",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS",
        "tight": "true",
        "wrap": "false"
    },
    "_4023": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":1},
        "bgcolor": "black54",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "border_radius": {"bl":38.0,"br":38.0,"tl":38.0,"tr":38.0},
        "expand": "",
        "height": "",
        "ink": "false",
        "ink_color": "red",
        "margin": {"l":0.0,"t":0.0,"r":0.0,"b":0.0},
        "padding": {"l":14.0,"t":14.0,"r":14.0,"b":14.0},
        # "tooltip": ""Text: 10"",
        "width": ""
    },
    "_4024": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "bgcolor": "transparent",
        "color": "lightblue50",
        "disabled": "false",
        "expand": "1",
        "height": "",
        "size": 16.0,
        "text_align": "left",
        # "tooltip": ""Text"",
        "value": "1. Representa el nivel superior en la actividad gastronu00f3mica, respondiendo al Gerente o Director General (bu00e1sicamente de instalaciones hoteleras) por todo lo relacionado con la cocina, servicios gastronu00f3micos y bares. Al mismo tiempo se subordinan el Mau00eetre y el Chef.",
        "width": ""
    },
    "_3995": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent","sa":"null"},"t":{"w":0,"c":"transparent","sa":"null"},"r":{"w":0,"c":"transparent","sa":"null"},"b":{"w":0,"c":"transparent","sa":"null"}},
        "height": "120",
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        # "tooltip": ""Column: 3"",
        "width": ""
    },
    "_3996": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    }
}